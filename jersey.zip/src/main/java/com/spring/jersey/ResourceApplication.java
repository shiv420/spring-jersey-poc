package com.spring.jersey;

import com.spring.jersey.config.RequestFilter;
import com.spring.jersey.resource.WelcomeResource;

import org.glassfish.jersey.server.ResourceConfig;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import java.util.Set;

@Configuration
@Component
public class ResourceApplication extends ResourceConfig {

    public ResourceApplication(){
        registerClasses(
                WelcomeResource.class,
                RequestFilter.class
        );
    }


}
