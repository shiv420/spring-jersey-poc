package com.spring.jersey;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJerseyApplicationTests {

	@Test
	void contextLoads() {
	}

}
