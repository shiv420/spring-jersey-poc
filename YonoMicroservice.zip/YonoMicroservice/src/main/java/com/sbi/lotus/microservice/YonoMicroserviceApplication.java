package com.sbi.lotus.microservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YonoMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(YonoMicroserviceApplication.class, args);
	}

}
