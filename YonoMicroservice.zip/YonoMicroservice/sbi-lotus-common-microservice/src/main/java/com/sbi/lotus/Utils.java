package com.sbi.lotus;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;

public class Utils {
    public static String systemInfo(){

        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("cores" ,
                Runtime.getRuntime().availableProcessors());
        jsonObject.addProperty("freeMemory",Runtime.getRuntime().freeMemory());

        return new GsonBuilder().setPrettyPrinting().create().toJson(jsonObject);
    }
}
