package com.sbi.lotus.home.config;

import com.sbi.lotus.home.resource.WelcomeResource;
import org.glassfish.jersey.server.ResourceConfig;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Configuration
@Component
public class HomeResoureConfig extends ResourceConfig {

    public HomeResoureConfig(){
        registerClasses(
                WelcomeResource.class

        );
    }
}
