package com.sbi.lotus.home.resource;

import com.sbi.lotus.Utils;
import org.springframework.stereotype.Component;

import javax.ws.rs.GET;
import javax.ws.rs.Path;

@Component
@Path("/v1/api/")
public class LoginResource {

    @GET
    @Path("welcome")
    public String welome(){

        return "Welcome Boot Multi Module project :" + Utils.systemInfo();
    }

}
