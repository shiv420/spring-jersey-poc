package com.sbi.lotus.home.config;

import com.sbi.lotus.home.resource.LoginResource;
import org.glassfish.jersey.server.ResourceConfig;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Configuration
@Component
public class LoginResourceConfig extends ResourceConfig {

    public LoginResourceConfig(){
        registerClasses(
                LoginResource.class
        );
    }
}
